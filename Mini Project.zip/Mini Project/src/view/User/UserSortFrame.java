package view.User;

import java.awt.*;

import Controller.Windowlistner;

public class UserSortFrame extends Frame{
 
	Button btSalary, btId;
	
	public UserSortFrame() {
		btSalary = new Button("Salary");
		btId = new Button("Id");
		
		this.setVisible(true);
		this.setResizable(false);
		this.setBounds(200, 200, 300, 200);
		this.setLayout(new FlowLayout());
		this.setTitle("Sort By");
		
		this.add(btSalary);
		this.add(btId);
		
		Windowlistner l1 = new Windowlistner(this);
		this.addWindowListener(l1);
	}
}
