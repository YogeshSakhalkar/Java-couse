package view.User.seaech;

import java.awt.*;

import Controller.Windowlistner;

public class UserNameSerchFrame extends Frame{
	Button btSubmit,btClear;
	TextField txtName;
	Label lbName;
	
	public UserNameSerchFrame() {
		btSubmit = new Button("Submit");
		btClear = new Button("Clear");
		
		txtName = new TextField(20);
		
		lbName = new Label("Name");
		
		this.setTitle("Search By Name");
		this.setVisible(true);
		this.setBounds(300, 200, 200, 350);
		this.setLayout(new FlowLayout());
		this.setResizable(false);
		this.add(lbName);
		this.add(txtName);
		this.add(btSubmit);
		this.add(btClear);
		
		Windowlistner mw = new Windowlistner(this);
		this.addWindowListener(mw);
	}
}
