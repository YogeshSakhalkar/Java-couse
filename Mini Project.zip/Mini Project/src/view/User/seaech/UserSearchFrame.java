package view.User.seaech;

import java.awt.*;

import Controller.Windowlistner;

public class UserSearchFrame extends Frame{

	Button btName, btId;
	public UserSearchFrame() {

		btName = new Button("Name");
		btId = new Button("Id");
		
		this.setVisible(true);
		this.setResizable(false);
		this.setBounds(200, 200, 300, 200);
		this.setLayout(new FlowLayout());
		this.setTitle("Search Page");
		
		this.add(btName);
		this.add(btId);
		
		Windowlistner l1 = new Windowlistner(this);
		this.addWindowListener(l1);
	}
	
}
