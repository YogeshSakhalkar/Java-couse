package view.User;

import java.awt.*;

import Controller.Windowlistner;

public class UserCalSalSearchFrame extends Frame{
	Button btSubmit,btClear;
	TextField txtId;
	Label lbId;
	
	public UserCalSalSearchFrame() {
		btSubmit = new Button("Submit");
		btClear = new Button("Clear");
		
		txtId = new TextField(20);
		
		lbId = new Label("Id");
		
		this.setTitle("Calulate Salary");
		this.setVisible(true);
		this.setBounds(300, 200, 200, 350);
		this.setLayout(new FlowLayout());
		this.setResizable(false);
		this.add(lbId);
		this.add(txtId);
		this.add(btSubmit);
		this.add(btClear);
		
		Windowlistner mw = new Windowlistner(this);
		this.addWindowListener(mw);
	}
}
