package view.User;

import java.awt.*;

import Controller.Windowlistner;

public class UserHomepageFrame extends Frame{

	Button btSearch, btCheck, btCalsal;
	
	public UserHomepageFrame() {
		
		btSearch = new Button("Search");
		btCheck = new Button("Check");
		btCalsal = new Button("Calulate Salary");
		
		this.setVisible(true);
		this.setBounds(200, 200, 500, 500);
		this.setResizable(false);
		this.setTitle("Welcome User");
		this.setLayout(new FlowLayout());
		
		this.add(btSearch);
		this.add(btCheck);
		this.add(btCalsal);
		
		Windowlistner l1 = new Windowlistner(this);
		this.addWindowListener(l1);
	}
	
}
