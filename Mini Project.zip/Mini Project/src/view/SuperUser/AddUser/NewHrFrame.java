package view.SuperUser.AddUser;

import java.awt.*;

import Controller.Windowlistner;

public class NewHrFrame extends Frame{

	Button btSubmit,btClear;
	TextField txtId, txtName, txtSalary, txtAllowance; 
	Label lbId, lbName, lbSalary, lbAllowance;
	
	public NewHrFrame() {
		btSubmit = new Button("Submit");
		btClear = new Button("Clear");
		
		txtId = new TextField(20);
		txtName = new TextField(20);
		txtSalary = new TextField(20);
		txtAllowance = new TextField(20);
		
		lbId = new Label("Id");
		lbName = new Label("Name");
		lbSalary = new Label("Salary");
		lbAllowance = new Label("Allowance");

		
		this.setTitle("Sales Manager");
		this.setVisible(true);
		this.setBounds(300, 200, 200, 350);
		this.setLayout(new FlowLayout());
		this.setResizable(false);
		this.add(lbId);
		this.add(txtId);
		this.add(lbName);
		this.add(txtName);
		this.add(lbSalary);
		this.add(txtSalary);
		this.add(lbAllowance);
		this.add(txtAllowance);
		this.add(btSubmit);
		this.add(btClear);
		
		
		
		Windowlistner mw = new Windowlistner(this);
		this.addWindowListener(mw);
}
}
