package view.SuperUser.AddUser;

import java.awt.*;

import Controller.Windowlistner;

public class NewSalesManagerFrame extends Frame{
	Button btSubmit,btClear;
	TextField txtId, txtName, txtSalary, txtIncentive, txtTarget;
	Label lbId, lbName, lbSalary, lbIncentive, lbTarget;
	
	public NewSalesManagerFrame() {
		btSubmit = new Button("Submit");
		btClear = new Button("Clear");
		
		txtId = new TextField(20);
		txtName = new TextField(20);
		txtSalary = new TextField(20);
		txtIncentive = new TextField(20);
		txtTarget = new TextField(20);
		
		lbId = new Label("Id");
		lbName = new Label("Name");
		lbSalary = new Label("Salary");
		lbTarget = new Label("Target");
		lbIncentive = new Label("Incentive");
		
		this.setTitle("Sales Manager");
		this.setVisible(true);
		this.setBounds(300, 200, 200, 350);
		this.setLayout(new FlowLayout());
		this.setResizable(false);
		this.add(lbId);
		this.add(txtId);
		this.add(lbName);
		this.add(txtName);
		this.add(lbSalary);
		this.add(txtSalary);
		this.add(lbIncentive);
		this.add(txtIncentive);
		this.add(lbTarget);
		this.add(txtTarget);
		this.add(btSubmit);
		this.add(btClear);
		
		
		
		Windowlistner mw = new Windowlistner(this);
		this.addWindowListener(mw);
	}
}
