package view.SuperUser.AddUser;

import java.awt.*;

public class UserAddFrame extends Frame{
	
	public UserAddFrame() {
		
	}
}
