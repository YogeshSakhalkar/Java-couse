package view.SuperUser;

import java.awt.*;

import Controller.Windowlistner;

public class SuperClassHomepageFrame extends Frame{

	Button btAddUser, btRemoveUser, btEditUser;
	
	public SuperClassHomepageFrame() {
		btAddUser = new Button("Add User");
		btRemoveUser = new Button("Remove User");
		btEditUser = new Button("Edit User");
		
		this.setVisible(true);
		this.setResizable(false);
		this.setBounds(200, 200, 500, 500);
		this.setTitle("Welocome SuperUser");
		
		this.setLayout(new FlowLayout());
		
		this.add(btAddUser);
		this.add(btEditUser);
		this.add(btRemoveUser);
		
		Windowlistner l1 =  new Windowlistner(this);
		this.addWindowListener(l1);
	}
}
