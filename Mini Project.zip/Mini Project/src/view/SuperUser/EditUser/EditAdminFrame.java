package view.SuperUser.EditUser;

import java.awt.*;

import Controller.Windowlistner;

public class EditAdminFrame extends Frame{

	Button btSubmit,btClear;
	TextField  txtName, txtSalary, txtAllowance; 
	Label lbName, lbSalary, lbAllowance;
	public EditAdminFrame() {
		btSubmit = new Button("Submit");
		btClear = new Button("Clear");
		
		txtName = new TextField(20);
		txtSalary = new TextField(20);
		txtAllowance = new TextField(20);
		
		lbName = new Label("Name");
		lbSalary = new Label("Salary");
		lbAllowance = new Label("Allowance");

		
		this.setTitle("Edit Admin");
		this.setVisible(true);
		this.setBounds(300, 200, 200, 350);
		this.setLayout(new FlowLayout());
		this.setResizable(false);

		this.add(lbName);
		this.add(txtName);
		this.add(lbSalary);
		this.add(txtSalary);
		this.add(lbAllowance);
		this.add(txtAllowance);
		this.add(btSubmit);
		this.add(btClear);
		
		
		
		Windowlistner mw = new Windowlistner(this);
		this.addWindowListener(mw);
	}
}
