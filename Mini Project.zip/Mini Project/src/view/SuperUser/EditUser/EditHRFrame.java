package view.SuperUser.EditUser;

import java.awt.*;

import Controller.Windowlistner;

public class EditHRFrame extends Frame{
 
	Button btSubmit,btClear;
	TextField  txtName, txtSalary, txtCommission; 
	Label lbName, lbSalary, lbCommission;
	public EditHRFrame() {
		btSubmit = new Button("Submit");
		btClear = new Button("Clear");
		

		txtName = new TextField(20);
		txtSalary = new TextField(20);
		txtCommission = new TextField(20);
		

		lbName = new Label("Name");
		lbSalary = new Label("Salary");
		lbCommission = new Label("Commission");

		
		this.setTitle("Edit HR");
		this.setVisible(true);
		this.setBounds(300, 200, 200, 350);
		this.setLayout(new FlowLayout());
		this.setResizable(false);

		this.add(lbName);
		this.add(txtName);
		this.add(lbSalary);
		this.add(txtSalary);
		this.add(lbCommission);
		this.add(txtCommission);
		this.add(btSubmit);
		this.add(btClear);
		
		
		
		Windowlistner mw = new Windowlistner(this);
		this.addWindowListener(mw);
 }
}
