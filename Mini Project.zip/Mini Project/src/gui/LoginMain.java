package gui;

import view.LoginFrame;

public class LoginMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginFrame l1 = new LoginFrame();
	}

}
