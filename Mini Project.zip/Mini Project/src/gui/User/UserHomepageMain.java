package gui.User;

import view.User.UserHomepageFrame;

public class UserHomepageMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserHomepageFrame f1 = new UserHomepageFrame();
	}

}
