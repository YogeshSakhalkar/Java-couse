package gui.User;

import view.User.UserSortFrame;

public class UserSortMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserSortFrame f1 = new UserSortFrame();
	}

}
