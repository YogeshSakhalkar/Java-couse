package gui.User;

import view.User.UserCalSalSearchFrame;

public class UserCalSalSearchMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserCalSalSearchFrame U1 = new UserCalSalSearchFrame();
	}

}
