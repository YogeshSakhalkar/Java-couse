package gui.User.Search;

import view.User.seaech.UserSearchFrame;

public class UserSearchMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserSearchFrame u1 = new UserSearchFrame();
	}

}
