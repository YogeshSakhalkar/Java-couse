package gui.User.Search;

import view.User.seaech.UserNameSerchFrame;

public class UserNameSearchMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserNameSerchFrame uns = new UserNameSerchFrame();
	}

}
