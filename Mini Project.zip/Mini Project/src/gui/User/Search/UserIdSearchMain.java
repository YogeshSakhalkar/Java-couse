package gui.User.Search;

import view.User.seaech.UserIdSearchFrame;

public class UserIdSearchMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserIdSearchFrame u1 = new UserIdSearchFrame();
	}

}
