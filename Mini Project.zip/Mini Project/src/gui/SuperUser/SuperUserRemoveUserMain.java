package gui.SuperUser;

import view.SuperUser.SuperUserRemoveUserFrame;

public class SuperUserRemoveUserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperUserRemoveUserFrame s1 = new SuperUserRemoveUserFrame();
	}

}
