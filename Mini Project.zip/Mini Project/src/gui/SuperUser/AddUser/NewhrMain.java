package gui.SuperUser.AddUser;

import view.SuperUser.AddUser.NewHrFrame;

public class NewhrMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewHrFrame hf = new NewHrFrame();
	}

}
