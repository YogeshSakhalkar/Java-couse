package gui.SuperUser.AddUser;

import view.SuperUser.AddUser.UserAddFrame;

public class UserAddMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserAddFrame u1 = new UserAddFrame();
		
	}

}
