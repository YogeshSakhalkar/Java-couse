package gui.SuperUser.AddUser;

import view.SuperUser.AddUser.NewAdminFrame;

public class NewAdminMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewAdminFrame af1 =  new NewAdminFrame(); 
	}

}
