package gui.SuperUser.AddUser;

import view.SuperUser.AddUser.NewSalesManagerFrame;

public class NewsalesManagerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewSalesManagerFrame sm = new NewSalesManagerFrame();
	}

}
