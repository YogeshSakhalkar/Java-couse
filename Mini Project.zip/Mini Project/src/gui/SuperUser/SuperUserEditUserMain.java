package gui.SuperUser;

import view.SuperUser.SuperUserEditUserFrame;

public class SuperUserEditUserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperUserEditUserFrame s1 = new SuperUserEditUserFrame();
	}

}
