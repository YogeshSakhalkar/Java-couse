package gui.SuperUser.EditUser;

import view.SuperUser.EditUser.EditAdminFrame;

public class EditAdminMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EditAdminFrame eaf = new EditAdminFrame();
	}

}
