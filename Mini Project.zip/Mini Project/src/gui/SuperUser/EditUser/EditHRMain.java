package gui.SuperUser.EditUser;

import view.SuperUser.EditUser.EditHRFrame;

public class EditHRMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EditHRFrame ehf = new EditHRFrame();
	}

}
