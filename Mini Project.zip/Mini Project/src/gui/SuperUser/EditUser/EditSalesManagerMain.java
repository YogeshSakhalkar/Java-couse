package gui.SuperUser.EditUser;

import view.SuperUser.EditUser.EditSalesManagerFrame;

public class EditSalesManagerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EditSalesManagerFrame esf = new EditSalesManagerFrame();
	}

}
