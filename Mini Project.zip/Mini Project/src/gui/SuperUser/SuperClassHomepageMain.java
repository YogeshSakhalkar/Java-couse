package gui.SuperUser;

import view.SuperUser.SuperClassHomepageFrame;

public class SuperClassHomepageMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperClassHomepageFrame s1 = new SuperClassHomepageFrame(); 
	}

}
